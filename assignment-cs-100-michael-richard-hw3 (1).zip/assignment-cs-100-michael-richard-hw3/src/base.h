#ifndef BASE_H
#define BASE_H

class base{
   public:
      void separateCommand();
      int execute();
};

#endif
