#!/bin/sh

./a.out integration_tests/test_command_tests.txt
