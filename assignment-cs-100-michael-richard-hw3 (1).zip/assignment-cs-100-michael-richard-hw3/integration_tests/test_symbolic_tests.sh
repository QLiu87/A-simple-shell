#!/bin/sh

./a.out integration_tests/test_symbolic_tests.txt
