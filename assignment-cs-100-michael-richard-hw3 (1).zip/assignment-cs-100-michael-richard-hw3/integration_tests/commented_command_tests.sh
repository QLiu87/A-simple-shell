#!/bin/sh


INPUTS=("echo hello # echo world ")
 
    echo "Testing echo hello # echo world"

    ./CommentedComand ${INPUTS[0]}
  



