#!/bin/sh


INPUTS=("exit")
 
    echo "Testing exit command"

    ./exit_test ${INPUTS[0]}
  


